
import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np
import sounddevice as sd
import math
from sklearn.decomposition import FastICA
import noisereduce as nr
import soundfile as sf

#%%
# Rutas de los audios
loc_audio1 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Audio 1.wav'
loc_audio2 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Audio 2.wav'
loc_audio3 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Audio 3.wav'

# Rutas de los ruidos
loc_ruido1 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Ruido 1.wav'
loc_ruido2 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Ruido 2.wav'
loc_ruido3 = r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\Audios\Ruido 3.wav'

# Cargar audios y ruidos con librosa 
audio1, sr1 = librosa.load(loc_audio1, sr=None)
ruido1, sr1 = librosa.load(loc_ruido1, sr=None)

audio2, sr2 = librosa.load(loc_audio2, sr=None)
ruido2, sr2 = librosa.load(loc_ruido2, sr=None)

audio3, sr3 = librosa.load(loc_audio3, sr=None)
ruido3, sr3 = librosa.load(loc_ruido3, sr=None)

#%%
# Función para graficar y reproducir audio y ruido
def graficas(audio, ruido, sr, color, tituloA, tituloR, tituloC):
    
    # Graficar audio
    plt.figure(figsize=(16, 16))
    plt.subplot(3, 1, 1)
    plt.plot(np.linspace(0, len(audio) / sr, num=len(audio)), audio, color=color)
    plt.title(tituloA)
    plt.xlabel('Tiempo [s]')
    plt.ylabel('Amplitud')
    plt.grid(True)
    
    # Reproducir audio
    print(f'Se está reproduciendo {tituloA}...')
    sd.play(audio, sr)
    sd.wait()  

    # Graficar ruido
    plt.subplot(3, 1, 2)
    plt.plot(np.linspace(0, len(ruido) / sr, num=len(ruido)), ruido, color=color)
    plt.title(tituloR)
    plt.xlabel('Tiempo [s]')
    plt.ylabel('Amplitud')
    plt.grid(True)
    
    # Reproducir ruido
    print(f'Se está reproduciendo {tituloR}...')
    sd.play(ruido, sr)
    sd.wait()  
    
    # Audio con ruido
    # Asegurar que tanto el audio como el ruido tengan el mismo tamano
    if len(audio) > len(ruido):
        ruido = np.pad(ruido, (0, len(audio) - len(ruido)), 'constant')
    else:
        audio = np.pad(audio, (0, len(ruido) - len(audio)), 'constant')
        
    combinado = audio + ruido
    
    plt.subplot(3, 1, 3)
    plt.plot(np.linspace(0, len(combinado) / sr, num=len(combinado)), combinado, color=color)
    plt.title(tituloC)
    plt.xlabel('Tiempo [s]')
    plt.ylabel('Amplitud')
    plt.grid(True)
    
    return audio, ruido, combinado
#%%
# Función para calcular SNR
def calcular_snr(audio, ruido):
    la = len(audio) #Longitud del audio
    lr = len(ruido) #Longitud del ruido
    
    Pa = (sum(audio**2)) / la #Potencia del audio
    Pr = (sum(ruido**2)) / lr #Potencia del ruido
    b = Pa / Pr
    print('La potencia de la senal es', Pa)
    print('La potencia del ruido es', Pa)
    return 10 * math.log10(b)

#%%
# Función para analizar y graficar una señal
def analisis_espectral(audio, sr, titulo):
    # Parámetros para STFT
    n_fft = 2048
    hop_length = 512

    # Realizar STFT
    S = librosa.stft(audio, n_fft=n_fft, hop_length=hop_length)
    S_db = librosa.amplitude_to_db(np.abs(S), ref=np.max)
    
    # Reproducir el audio
    print(f"Reproduciendo {titulo}...")
    sd.play(audio, sr)
    sd.wait()  # Esperar a que termine la reproducción

    # Graficar la forma de onda
    plt.figure(figsize=(12, 4))
    librosa.display.waveshow(audio, sr=sr, color='orange')
    plt.title(f'Forma de Onda del {titulo}')
    plt.xlabel('Tiempo [s]')
    plt.ylabel('Amplitud')
    plt.show()
    
    # Graficar el espectrograma
    plt.figure(figsize=(12, 6))
    librosa.display.specshow(S_db, sr=sr, x_axis='time', y_axis='log', cmap='viridis')
    plt.colorbar(format='%+2.0f dB')
    plt.title(f'Espectrograma del {titulo}')
    plt.xlabel('Tiempo [s]')
    plt.ylabel('Frecuencia [Hz]')
    plt.show()
    
    # Obtener magnitudes y fases
    magnitudes = np.abs(S)
    fases = np.angle(S)
    
    # Obtener frecuencias y tiempos
    frecuencias = librosa.fft_frequencies(n_fft=n_fft)
    tiempos = librosa.frames_to_time(np.arange(S.shape[1]), sr=sr, hop_length=hop_length)
    

   
    # Estadísticas descriptivas
    print("Estadísticas de magnitudes:")
    print(f"Media: {np.mean(magnitudes)}")
    print(f"Desviación estándar: {np.std(magnitudes)}")
    print(f"Máximo: {np.max(magnitudes)}")
    print(f"Mínimo: {np.min(magnitudes)}")
    
    # Estadísticas descriptivas
    print("Estadísticas de frecuencias:")
    print(f"Media: {np.mean(frecuencias)}")
    print(f"Desviación estándar: {np.std(frecuencias)}")
    print(f"Máximo: {np.max(frecuencias)}")
    print(f"Mínimo: {np.min(frecuencias)}")

   

#%%
# Función para guardar el audio en un archivo
def save_audio(file_path, audio, sr):
    sf.write(file_path, audio, sr)
    print(f"Audio guardado en {file_path}")
    
#%%
# Procesar cada par de audio y ruido
audio1, ruido1, combinado1 = graficas(audio1, ruido1, sr1, 'blue', 'Forma de onda del audio 1', 'Forma de onda del ruido 1', 'Forma de onda del audio con el ruido 1')
snr1 = calcular_snr(audio1, ruido1)
print(f'El SNR para el audio y ruido 1 es: {snr1}')

audio2, ruido2, combinado2 = graficas(audio2, ruido2, sr2, 'green', 'Forma de onda del audio 2', 'Forma de onda del ruido 2', 'Forma de onda del audio con el ruido 2')
snr2 = calcular_snr(audio2, ruido2)
print(f'El SNR para el audio y ruido 2 es: {snr2}')

audio3, ruido3, combinado3 = graficas(audio3, ruido3, sr3, 'red', 'Forma de onda del audio 3', 'Forma de onda del ruido 3', 'Forma de onda del audio con el ruido 3')
snr3 = calcular_snr(audio3, ruido3)
print(f'El SNR para el audio y ruido 3 es: {snr3}')

#%%
# -------------------ANÁLISIS DE COMPONENTES INDEPENDIENTES--------------------------
# Encontrar la longitud máxima entre todas las señales
max_length = max(len(audio1), len(audio2), len(audio3))

# Rellenar las señales más cortas con ceros para que tengan la misma longitud
audio1_padded = np.pad(audio1, (0, max_length - len(audio1)), mode='constant')
audio2_padded = np.pad(audio2, (0, max_length - len(audio2)), mode='constant')
audio3_padded = np.pad(audio3, (0, max_length - len(audio3)), mode='constant')

# Crear una matriz de señales
X = np.vstack([audio1_padded, audio2_padded, audio3_padded]).T  # Transponer para que cada columna sea una señal

# Centrar y normalizar las señales
X -= np.mean(X, axis=0)  # Centrar en torno a cero
X /= np.std(X, axis=0)   # Normalizar a varianza unitaria

# Aplicar ICA
ica = FastICA(n_components=3, random_state=0)  # Número de componentes igual al número de señales originales
S_ica = ica.fit_transform(X)  # Componentes independientes

# Guardar las señales separadas en variables para análisis posterior
audio_separado = S_ica[:, 2]  # Seleccionar la columna 2 que corresponde a la señal separada 2

# Graficar y reproducir la señal original y la señal separada 2
analisis_espectral(audio2_padded, sr2, 'audio 2 original')

audio_filtrado = nr.reduce_noise(y=audio2_padded, sr=sr2)  
analisis_espectral(audio_filtrado, sr2, ' señal separada 2')


snr_filtrado = calcular_snr(audio2_padded, audio_filtrado)
print(f'El SNR para el audio2 y audio filtrado es: {snr_filtrado}')

# Guardar el audio filtrado en un archivo
save_audio(r'C:\Users\Automatizacion 2\Downloads\V\Lab2Señales\AudiosF\Audio_Filtrado.wav', audio_filtrado, sr2)